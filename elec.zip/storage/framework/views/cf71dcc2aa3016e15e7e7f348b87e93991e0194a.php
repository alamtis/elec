<!-- Footer opened -->
 <footer class="bg-white p-4">
      <div class="row">
        <div class="col">
          <div class="text-center">
              <p class="mb-0"> &copy; Copyright <span id="copyright"> <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span>. <a href="#"> Naji Services </a> All Rights Reserved. </p>
          </div>
        </div>
      </div>
    </footer>
<!-- Footer closed -->
<?php /**PATH C:\laragon\www\elec\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
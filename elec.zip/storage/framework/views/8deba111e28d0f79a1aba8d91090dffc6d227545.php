<!-- Title -->
<title><?php echo $__env->yieldContent("title"); ?></title>

<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon"/>

<!-- Font -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600&display=swap" rel="stylesheet">
<?php echo $__env->yieldContent('css'); ?>

<?php if(App::getLocale() == 'en'): ?>
    <link href="<?php echo e(asset('assets/css/ltr.css')); ?>" rel="stylesheet">
<?php else: ?>
    <link href="<?php echo e(asset('assets/css/rtl.css')); ?>" rel="stylesheet">
<?php endif; ?>
<?php /**PATH C:\laragon\www\elec\resources\views/layouts/head.blade.php ENDPATH**/ ?>
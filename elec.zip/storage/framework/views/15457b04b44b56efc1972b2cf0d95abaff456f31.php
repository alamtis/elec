<?php $__env->startSection('title', 'الرئيسية'); ?>

<?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.0.3/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0"> الرئيسية</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row my-5">
    <div class="col">
    <div class="card">

        <div class="card-header">
            <h5>لائحة المصوتين</h5>
        </div>
        <div class="card-body">
            <button type="button" class="button x-small d-block mb-3 w-100" data-toggle="modal" data-target=".bd-example-modal-lg">أضف مصوت
            </button>
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
    </div>
</div>
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" style="display: none;"
             aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title">
                            <div class="mb-30">
                                <h6>إضافة مصوت</h6>
                            </div>
                        </div>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('voters.store')); ?>" method="POST" id="voter">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="fname">إسم المصوت</label>
                                <input type="text" name="fname" class="form-control" id="fname">
                            </div>
                            <div class="form-group">
                                <label for="lname">نسب المصوت</label>
                                <input type="text" name="lname" class="form-control" id="lname">
                            </div>
                            <div class="form-group">
                                <label for="cin">رقم البطاقة الوطنية</label>
                                <input type="text" name="cin" class="form-control" id="cin">
                            </div>
                            <div class="form-group">
                                <label for="municipality">الجماعة الترابية</label>
                                <select name="municipality" class="form-control">
                                    <?php $__currentLoopData = $municipalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($municipality->id); ?>"><?php echo e($municipality->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="circle">الدائرة</label>
                                <input type="number" name="circle" class="form-control" id="circle">
                            </div>
                            <div class="form-group">
                                <label for="bureau">المكتب</label>
                                <input type="number" name="bureau" class="form-control" id="bureau">
                            </div>
                            <button type="submit" class="button x-small">حفظ</button>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>

            // toastr config
            toastr.options = {
            "closeButton": false,
            "debug": false,
            "newestOnTop": false,
            "progressBar": false,
            "positionClass": "toast-top-center",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "500",
            "timeOut": "2000",
            "extendedTimeOut": "500",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }

        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error('<?php echo e($error); ?>');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(Session::has('success')): ?>
        toastr.success('<?php echo e(Session::get('success')); ?>');
        <?php elseif(Session::has('unreserved')): ?>
        toastr.success('<?php echo e(Session::get('unreserved')); ?>');
        <?php elseif(Session::has('reserved')): ?>
        toastr.success('<?php echo e(Session::get('reserved')); ?>');
        <?php elseif(Session::has('voted')): ?>
        toastr.success('<?php echo e(Session::get('voted')); ?>');
        <?php endif; ?>

    </script>
    <script src="https://cdn.datatables.net/buttons/1.0.3/js/dataTables.buttons.min.js"></script>
<script src="/vendor/datatables/buttons.server-side.js"></script>
<?php echo $dataTable->scripts(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elec\resources\views/dashboard.blade.php ENDPATH**/ ?>